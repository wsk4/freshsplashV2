package com.freshsplash.cl.freshsplash.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.freshsplash.cl.freshsplash.assemblers.UbicacionModelAssembler;
import com.freshsplash.cl.freshsplash.model.Ubicacion;
import com.freshsplash.cl.freshsplash.service.UbicacionService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v2/ubicaciones")
@Tag(name = "Api que administra las ubicaciones de los baños-V2")

public class UbicacionControllerV2 {

    @Autowired
    private UbicacionService ubicacionService;

    @Autowired
    private UbicacionModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar todas las ubicaciones", description = "Recupera todas las ubicaciones de baños registradas en el sistema, devolviendo un modelo enriquecido con enlaces HATEOAS.")
    public CollectionModel<EntityModel<Ubicacion>> getAllUbicaciones() {
        List<EntityModel<Ubicacion>> ubicaciones = ubicacionService.findAll().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(ubicaciones,
                linkTo(methodOn(UbicacionControllerV2.class).getAllUbicaciones()).withSelfRel());
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener ubicación por ID", description = "Permite recuperar una ubicación específica de un baño mediante su identificador único. Devuelve la información en formato HATEOAS.")
    public ResponseEntity<EntityModel<Ubicacion>> getUbicacionById(@PathVariable Long id) {
        Ubicacion ubicacion = ubicacionService.findById(id);
        if (ubicacion == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(ubicacion));
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Registrar una nueva ubicación", description = "Permite crear una nueva ubicación de baño en el sistema. Devuelve el recurso creado con su URI correspondiente y enlaces HATEOAS.")
    public ResponseEntity<EntityModel<Ubicacion>> createUbicacion(@RequestBody Ubicacion ubicacion) {
        Ubicacion nuevaUbicacion = ubicacionService.save(ubicacion);
        return ResponseEntity
                .created(linkTo(
                        methodOn(UbicacionControllerV2.class).getUbicacionById(Long.valueOf(nuevaUbicacion.getId())))
                        .toUri())
                .body(assembler.toModel(nuevaUbicacion));
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Actualizar completamente una ubicación", description = "Reemplaza completamente una ubicación existente con nuevos datos. Devuelve el recurso actualizado en formato HATEOAS.")
    public ResponseEntity<EntityModel<Ubicacion>> updateUbicacion(@PathVariable Long id,
            @RequestBody Ubicacion ubicacion) {
        ubicacion.setId(id.intValue());
        Ubicacion updated = ubicacionService.save(ubicacion);
        if (updated == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(updated));
    }

    @PatchMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Actualizar parcialmente una ubicación", description = "Permite modificar uno o más campos de una ubicación de baño existente. Retorna el recurso actualizado en formato HATEOAS.")
    public ResponseEntity<EntityModel<Ubicacion>> patchUbicacion(@PathVariable Long id,
            @RequestBody Ubicacion ubicacion) {
        Ubicacion patched = ubicacionService.patchUbicacion(id, ubicacion);
        if (patched == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(patched));
    }

    @DeleteMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Eliminar una ubicación", description = "Elimina la ubicación correspondiente al ID especificado. Si la operación es exitosa, devuelve una respuesta sin contenido.")
    public ResponseEntity<Void> deleteUbicacion(@PathVariable Long id) {
        Ubicacion existing = ubicacionService.findById(id);
        if (existing == null) {
            return ResponseEntity.notFound().build();
        }
        ubicacionService.delete(id);
        return ResponseEntity.noContent().build();
    }

}
