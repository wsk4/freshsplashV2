package com.freshsplash.cl.freshsplash.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.freshsplash.cl.freshsplash.model.Bano;
import com.freshsplash.cl.freshsplash.model.Calificacion;
import com.freshsplash.cl.freshsplash.model.Etiqueta;
import com.freshsplash.cl.freshsplash.model.Horario;
import com.freshsplash.cl.freshsplash.model.Imagen;
import com.freshsplash.cl.freshsplash.repository.BanoRepository;
import com.freshsplash.cl.freshsplash.repository.CalificacionRepository;
import com.freshsplash.cl.freshsplash.repository.EtiquetaRepository;
import com.freshsplash.cl.freshsplash.repository.HorarioRepository;
import com.freshsplash.cl.freshsplash.repository.ImagenRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class BanoService {

    @Autowired
    private BanoRepository banoRepository;

    @Autowired
    private CalificacionRepository calificacionRepository;

    @Autowired
    private EtiquetaRepository etiquetaRepository;

    @Autowired
    private HorarioRepository horarioRepository;

    @Autowired
    private ImagenRepository imagenRepository;

    public List<Bano> findAll() {
        return banoRepository.findAll();
    }

    public Bano findById(Long id) {
        return banoRepository.findById(id).orElse(null);
    }

    public Bano save(Bano bano) {
        return banoRepository.save(bano);
    }

    public void delete(Long id) {
        Bano bano = banoRepository.findById(id).orElse(null);
        if (bano == null) {
            return;
        }

        Calificacion calificacion = bano.getCalificacion();
        if (calificacion != null && banoRepository.countByCalificacionId(calificacion.getId()) == 1) {
            calificacionRepository.delete(calificacion);
        }

        Etiqueta etiqueta = bano.getEtiqueta();
        if (etiqueta != null && banoRepository.countByEtiquetaId(etiqueta.getId()) == 1) {
            etiquetaRepository.delete(etiqueta);
        }

        Horario horario = bano.getHorario();
        if (horario != null && banoRepository.countByHorarioId(horario.getId()) == 1) {
            horarioRepository.delete(horario);
        }

        Imagen imagen = bano.getImagen();
        if (imagen != null && banoRepository.countByImagenId(imagen.getId()) == 1) {
            imagenRepository.delete(imagen);
        }

        banoRepository.delete(bano);
    }

    public Bano patchBano(Long id, Bano parcialBano) {
        Optional<Bano> banoOptional = banoRepository.findById(id);
        if (banoOptional.isPresent()) {

            Bano banoToUpdate = banoOptional.get();

            if (parcialBano.getCapacidad() != null) {
                banoToUpdate.setCapacidad(parcialBano.getCapacidad());
            }
            if (parcialBano.getImagen() != null) {
                banoToUpdate.setImagen(parcialBano.getImagen());
            }
            if (parcialBano.getUbicacion() != null) {
                banoToUpdate.setUbicacion(parcialBano.getUbicacion());
            }
            if (parcialBano.getHorario() != null) {
                banoToUpdate.setHorario(parcialBano.getHorario());
            }
            if (parcialBano.getEtiqueta() != null) {
                banoToUpdate.setEtiqueta(parcialBano.getEtiqueta());
            }
            if (parcialBano.getCalificacion() != null) {
                banoToUpdate.setCalificacion(parcialBano.getCalificacion());
            }

            return banoRepository.save(banoToUpdate);
        } else {
            return null;
        }
    }

    public List<Bano> findByRegionPrecioYPuntuacion(String region, Integer precio, Integer puntuacion) {
        return banoRepository.findByRegionPrecioYPuntuacion(region, precio, puntuacion);
    }

    public List<Bano> findByComunaAccesoDiscapacitadoYPuntuacion(String comuna, boolean accesoDiscapacitado,
            Integer puntuacion) {
        return banoRepository.findByComunaAccesoDiscapacitadoYPuntuacion(comuna, accesoDiscapacitado, puntuacion);
    }

    public List<Bano> findByCiudadEtiquetaGratuitoYPuntuacion(String ciudad, boolean gratuito, Integer puntuacion) {
        return banoRepository.findByCiudadEtiquetaGratuitoYPuntuacion(ciudad, gratuito, puntuacion);
    }

    public List<Bano> findByPaisTipoSitioYPuntuacionMinima(String pais, Integer tipoSitioId, Integer minPuntuacion) {
        return banoRepository.findByPaisTipoSitioYPuntuacionMinima(pais, tipoSitioId, minPuntuacion);
    }

}
