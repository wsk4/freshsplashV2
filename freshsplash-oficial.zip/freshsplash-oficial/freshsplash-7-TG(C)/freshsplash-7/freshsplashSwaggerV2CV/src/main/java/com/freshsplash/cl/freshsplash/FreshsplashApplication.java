package com.freshsplash.cl.freshsplash;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FreshsplashApplication {

	public static void main(String[] args) {
		SpringApplication.run(FreshsplashApplication.class, args);
	}

}
