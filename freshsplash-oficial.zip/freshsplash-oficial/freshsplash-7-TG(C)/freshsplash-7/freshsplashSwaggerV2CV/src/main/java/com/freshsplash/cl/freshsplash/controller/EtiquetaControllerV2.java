package com.freshsplash.cl.freshsplash.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.freshsplash.cl.freshsplash.assemblers.EtiquetaModelAssembler;
import com.freshsplash.cl.freshsplash.model.Etiqueta;
import com.freshsplash.cl.freshsplash.service.EtiquetaService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v2/etiquetas")
@Tag(name = "Api que administra las etiquetas de los bañosV2")
public class EtiquetaControllerV2 {

    @Autowired
    private EtiquetaService etiquetaService;

    @Autowired
    private EtiquetaModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar todas las etiquetas con HATEOAS", description = "Recupera todas las etiquetas disponibles, incluyendo enlaces HATEOAS para navegación")

    public CollectionModel<EntityModel<Etiqueta>> getAllEtiquetas() {
        List<EntityModel<Etiqueta>> etiquetas = etiquetaService.obtenerEtiquetas().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(etiquetas,
                linkTo(methodOn(EtiquetaControllerV2.class).getAllEtiquetas()).withSelfRel());
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener una etiqueta específica con HATEOAS", description = "Devuelve una etiqueta individual por su ID, incluyendo enlaces de navegación HATEOAS")

    public ResponseEntity<EntityModel<Etiqueta>> getEtiquetaById(@PathVariable Long id) {
        Etiqueta etiqueta = etiquetaService.obtenerEtiquetaPorId(id);
        if (etiqueta == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(etiqueta));
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Crear una nueva etiqueta con HATEOAS", description = "Registra una nueva etiqueta asociada a un baño, incluyendo respuesta con enlaces HATEOAS")

    public ResponseEntity<EntityModel<Etiqueta>> createEtiqueta(@RequestBody Etiqueta etiqueta) {
        Etiqueta nuevaEtiqueta = etiquetaService.guardarEtiqueta(etiqueta);
        return ResponseEntity
                .created(linkTo(
                        methodOn(EtiquetaControllerV2.class).getEtiquetaById(Long.valueOf(nuevaEtiqueta.getId())))
                        .toUri())
                .body(assembler.toModel(nuevaEtiqueta));
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Actualizar completamente una etiqueta con HATEOAS", description = "Modifica todos los campos de una etiqueta existente, devolviendo la entidad actualizada con enlaces de navegación")

    public ResponseEntity<EntityModel<Etiqueta>> updateEtiqueta(@PathVariable Long id, @RequestBody Etiqueta etiqueta) {
        etiqueta.setId(id.intValue());
        Etiqueta updated = etiquetaService.guardarEtiqueta(etiqueta);
        if (updated == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(updated));
    }

    @PatchMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Esta api modificara la etiqueta de un baño", description = "Esta api permitira modificar la etiqueta de un baño")

    public ResponseEntity<EntityModel<Etiqueta>> patchEtiqueta(@PathVariable Long id, @RequestBody Etiqueta etiqueta) {
        Etiqueta patched = etiquetaService.actualizarEtiqueta(id, etiqueta);
        if (patched == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(patched));
    }

    @DeleteMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Eliminar una etiqueta con HATEOAS", description = "Elimina una etiqueta por su ID. Si no existe, devuelve 404. No retorna cuerpo en la respuesta")

    public ResponseEntity<Void> deleteEtiqueta(@PathVariable Long id) {
        Etiqueta existing = etiquetaService.obtenerEtiquetaPorId(id);
        if (existing == null) {
            return ResponseEntity.notFound().build();
        }
        etiquetaService.eliminarEtiqueta(id);
        return ResponseEntity.noContent().build();
    }
}
