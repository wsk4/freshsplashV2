package com.freshsplash.cl.freshsplash.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.freshsplash.cl.freshsplash.model.Bano;
import com.freshsplash.cl.freshsplash.service.BanoService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/baños")
@Tag(name = "Api que administra la informacion de los baños")
public class BanoController {

    @Autowired
    private BanoService banoService;

    @GetMapping
    @Operation(summary = "Listar todos los baños", description = "Obtiene un listado completo de todos los baños registrados en el sistema")
    public ResponseEntity<List<Bano>> listar() {
        List<Bano> banos = banoService.findAll();
        if (banos.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(banos);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener baño por ID", description = "Permite recuperar la información de un baño específico mediante su ID")
    public ResponseEntity<Bano> buscar(@PathVariable Long id) {
        try {
            Bano bano = banoService.findById(id);
            return ResponseEntity.ok(bano);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    @Operation(summary = "Crear un nuevo baño", description = "Registra un nuevo baño en el sistema con los datos proporcionados")
    public ResponseEntity<Bano> guardar(@RequestBody Bano bano) {
        Bano banoNuevo = banoService.save(bano);
        return ResponseEntity.status(HttpStatus.CREATED).body(banoNuevo);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar baño existente", description = "Actualiza completamente la información de un baño identificado por su ID")
    public ResponseEntity<Bano> actualizar(@PathVariable Long id, @RequestBody Bano bano) {
        try {
            banoService.save(bano);
            return ResponseEntity.ok(bano);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PatchMapping("/{id}")
    @Operation(summary = "Modificar parcialmente un baño", description = "Actualiza uno o más atributos específicos de un baño sin reemplazar toda la entidad")
    public ResponseEntity<Bano> patchBano(@PathVariable Long id, @RequestBody Bano partialBano) {
        try {
            Bano updatedBano = banoService.patchBano(id, partialBano);
            return ResponseEntity.ok(updatedBano);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar baño por ID", description = "Elimina del sistema un baño específico identificado mediante su ID")
    public ResponseEntity<?> eliminar(@PathVariable Long id) {
        try {
            banoService.delete(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

}
