package com.freshsplash.cl.freshsplash.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.freshsplash.cl.freshsplash.model.Etiqueta;
import com.freshsplash.cl.freshsplash.service.EtiquetaService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/etiquetas")
@Tag(name = "Api que administra las etiquetas de los baños")
public class EtiquetaController {

    @Autowired
    private EtiquetaService etiquetaService;

    @GetMapping
    @Operation(summary = "Listar todas las etiquetas", description = "Recupera la lista completa de etiquetas asociadas a los baños, incluyendo características como accesibilidad, costo, ubicación (tienda, restaurante, bencinera, etc.) y otros atributos")
    public ResponseEntity<List<Etiqueta>> listar() {
        List<Etiqueta> etiquetas = etiquetaService.obtenerEtiquetas();
        if (etiquetas.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(etiquetas);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener una etiqueta específica", description = "Permite recuperar una etiqueta individual mediante su ID, asociada a un baño específico")
    public ResponseEntity<Etiqueta> buscarEtiquetaPorId(@PathVariable Long id) {
        Etiqueta etiqueta = etiquetaService.obtenerEtiquetaPorId(id);
        if (etiqueta == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(etiqueta);
    }

    @PostMapping
    @Operation(summary = "Crear una nueva etiqueta", description = "Registra una nueva etiqueta con sus respectivas características, que podrá asociarse a uno o más baños")
    public ResponseEntity<Etiqueta> guardar(@RequestBody Etiqueta etiqueta) {
        Etiqueta nuevaEtiqueta = etiquetaService.guardarEtiqueta(etiqueta);
        return ResponseEntity.status(201).body(nuevaEtiqueta);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar una etiqueta existente", description = "Modifica por completo los datos de una etiqueta ya existente, vinculada a un baño determinado")
    public ResponseEntity<Etiqueta> actualizar(@PathVariable Long id, @RequestBody Etiqueta etiqueta) {
        Etiqueta etiquetaActualizada = etiquetaService.actualizarEtiqueta(id, etiqueta);
        if (etiquetaActualizada == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(etiquetaActualizada);
    }

    @PatchMapping("/{id}")
    @Operation(summary = "Modificar parcialmente una etiqueta", description = "Permite modificar parcialmente los datos de una etiqueta asociada a un baño específico")
    public ResponseEntity<Etiqueta> editar(@PathVariable Long id, @RequestBody Etiqueta etiqueta) {
        Etiqueta etiquetaActualizada = etiquetaService.actualizarEtiqueta(id, etiqueta);
        if (etiquetaActualizada == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(etiquetaActualizada);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar una etiqueta", description = "Elimina una etiqueta específica del sistema, la cual estaba asociada a un baño")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        etiquetaService.eliminarEtiqueta(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/discapacidad")
    @Operation(summary = "Listar etiquetas de accesibilidad", description = "Devuelve todas las etiquetas que indican si un baño es apto para personas con discapacidad")
    public ResponseEntity<List<Etiqueta>> obtenerAccesibles() {
        List<Etiqueta> etiquetas = etiquetaService.obtenerEtiquetasAccesoDiscapacitado();
        if (etiquetas.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(etiquetas);
    }

    @GetMapping("/gratuitas")
    @Operation(summary = "Listar etiquetas de baños gratuitos", description = "Devuelve todas las etiquetas que identifican baños que no requieren pago para su uso")
    public ResponseEntity<List<Etiqueta>> obtenerGratuitas() {
        List<Etiqueta> etiquetas = etiquetaService.obtenerEtiquetasGratuitas();
        if (etiquetas.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(etiquetas);
    }

}
