package com.freshsplash.cl.freshsplash.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.freshsplash.cl.freshsplash.model.Bano;

@Repository
public interface BanoRepository extends JpaRepository<Bano, Long> {

    @Query("SELECT b FROM Bano b "
            + "WHERE b.ubicacion.region = :region "
            + "AND b.etiqueta.precio = :precio "
            + "AND b.calificacion.puntuacion = :puntuacion")
    List<Bano> findByRegionPrecioYPuntuacion(@Param("region") String region, @Param("precio") Integer precio, @Param("puntuacion") Integer puntuacion);

    @Query("SELECT b FROM Bano b WHERE b.ubicacion.ciudad = :ciudad AND b.etiqueta.gratuito = :gratuito AND b.calificacion.puntuacion = :puntuacion")
    List<Bano> findByCiudadEtiquetaGratuitoYPuntuacion(@Param("ciudad") String ciudad, @Param("gratuito") boolean gratuito, @Param("puntuacion") Integer puntuacion);

    @Query("SELECT b FROM Bano b "
            + "WHERE b.ubicacion.comuna = :comuna "
            + "AND b.etiqueta.accesoDiscapacitado = :accesoDiscapacitado "
            + "AND b.calificacion.puntuacion = :puntuacion")
    List<Bano> findByComunaAccesoDiscapacitadoYPuntuacion(@Param("comuna") String comuna, @Param("accesoDiscapacitado") boolean accesoDiscapacitado, @Param("puntuacion") Integer puntuacion);

    @Query("SELECT b FROM Bano b "
            + "WHERE b.ubicacion.pais = :pais "
            + "AND b.etiqueta.tipoSitio.id = :tipoSitioId "
            + "AND b.calificacion.puntuacion >= :minPuntuacion")
    List<Bano> findByPaisTipoSitioYPuntuacionMinima(@Param("pais") String pais, @Param("tipoSitioId") Integer tipoSitioId, @Param("minPuntuacion") Integer minPuntuacion);
}
