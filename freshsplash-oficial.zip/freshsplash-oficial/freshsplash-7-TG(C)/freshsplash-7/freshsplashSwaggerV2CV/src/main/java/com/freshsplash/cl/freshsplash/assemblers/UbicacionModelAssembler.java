package com.freshsplash.cl.freshsplash.assemblers;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;
import org.springframework.stereotype.Component;

import com.freshsplash.cl.freshsplash.controller.UbicacionControllerV2;
import com.freshsplash.cl.freshsplash.model.Ubicacion;

@Component
public class UbicacionModelAssembler implements RepresentationModelAssembler<Ubicacion, EntityModel<Ubicacion>> {

    @SuppressWarnings("null")
    @Override
    public EntityModel<Ubicacion> toModel(Ubicacion ubicacion) {
        return EntityModel.of(ubicacion,
                linkTo(methodOn(UbicacionControllerV2.class).getUbicacionById(Long.valueOf(ubicacion.getId()))).withSelfRel(),
                linkTo(methodOn(UbicacionControllerV2.class).getAllUbicaciones()).withRel("todos"),
                linkTo(methodOn(UbicacionControllerV2.class).updateUbicacion(Long.valueOf(ubicacion.getId()), ubicacion)).withRel("actualizar"),
                linkTo(methodOn(UbicacionControllerV2.class).deleteUbicacion(Long.valueOf(ubicacion.getId()))).withRel("eliminar"),
                linkTo(methodOn(UbicacionControllerV2.class).patchUbicacion(Long.valueOf(ubicacion.getId()), ubicacion)).withRel("actualizar-parcial")
        );
    }
}
