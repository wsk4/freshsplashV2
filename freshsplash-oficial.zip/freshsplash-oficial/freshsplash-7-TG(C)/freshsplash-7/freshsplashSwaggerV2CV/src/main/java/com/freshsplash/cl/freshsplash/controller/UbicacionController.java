package com.freshsplash.cl.freshsplash.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.freshsplash.cl.freshsplash.model.Ubicacion;
import com.freshsplash.cl.freshsplash.service.UbicacionService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/ubicaciones")
@Tag(name = "Api que administra las ubicaciones de los baños")
public class UbicacionController {

    @Autowired
    private UbicacionService ubicacionService;

    @GetMapping
    @Operation(summary = "Listar todas las ubicaciones", description = "Recupera todas las ubicaciones de baños registradas en el sistema. Devuelve una lista vacía si no existen registros.")
    public ResponseEntity<List<Ubicacion>> listar() {
        List<Ubicacion> ubicaciones = ubicacionService.findAll();
        if (ubicaciones.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(ubicaciones);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener ubicación por ID", description = "Permite buscar y obtener una ubicación específica de un baño mediante su identificador único.")
    public ResponseEntity<Ubicacion> buscar(@PathVariable Long id) {
        try {
            Ubicacion ubicacion = ubicacionService.findById(id);
            return ResponseEntity.ok(ubicacion);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    @Operation(summary = "Registrar una nueva ubicación", description = "Permite guardar una nueva ubicación de baño en el sistema. Devuelve el recurso creado con su identificador correspondiente.")
    public ResponseEntity<Ubicacion> guardar(@RequestBody Ubicacion ubicacion) {
        Ubicacion ubicacionNueva = ubicacionService.save(ubicacion);
        return ResponseEntity.status(HttpStatus.CREATED).body(ubicacionNueva);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar parcialmente una ubicación", description = "Reemplaza completamente una ubicación existente por una nueva. Se requiere el ID de la ubicación a actualizar.")
    public ResponseEntity<Ubicacion> actualizar(@PathVariable Long id, @RequestBody Ubicacion ubicacion) {
        try {
            ubicacionService.save(ubicacion);
            return ResponseEntity.ok(ubicacion);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PatchMapping("/{id}")
    @Operation(summary = "Actualizar parcialmente una ubicación", description = "Modifica ciertos atributos de una ubicación específica de baño. Retorna el recurso modificado si la operación es exitosa.")
    public ResponseEntity<Ubicacion> patchUbicacion(@PathVariable Long id, @RequestBody Ubicacion partialUbicacion) {
        try {
            Ubicacion updatedUbicacion = ubicacionService.patchUbicacion(id, partialUbicacion);
            return ResponseEntity.ok(updatedUbicacion);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar una ubicación", description = "Elimina la ubicación correspondiente al ID proporcionado. Devuelve una respuesta vacía si la eliminación es exitosa.")
    public ResponseEntity<?> eliminar(@PathVariable Long id) {
        try {
            ubicacionService.delete(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

}
