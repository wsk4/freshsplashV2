package com.freshsplash.cl.freshsplash.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.freshsplash.cl.freshsplash.assemblers.CalificacionModelAssembler;
import com.freshsplash.cl.freshsplash.model.Calificacion;
import com.freshsplash.cl.freshsplash.service.CalificacionService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v2/calificaciones")
@Tag(name = "Api que controla las comentarios y puntuaciones de los baños-V2")

public class CalificacionControllerV2 {

    @Autowired
    private CalificacionService calificacionService;

    @Autowired
    private CalificacionModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener todas las calificaciones", description = "Recupera una colección de todas las calificaciones registradas, incluyendo comentarios y puntuaciones asociadas a los baños públicos")

    public CollectionModel<EntityModel<Calificacion>> getAllCalificaciones() {
        List<EntityModel<Calificacion>> calificaciones = calificacionService.findAll().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(calificaciones,
                linkTo(methodOn(CalificacionControllerV2.class).getAllCalificaciones()).withSelfRel());
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener una calificación específica", description = "Permite recuperar una calificación individual mediante su ID, incluyendo el comentario y la puntuación correspondientes")

    public ResponseEntity<EntityModel<Calificacion>> getCalificacionById(@PathVariable Long id) {
        Calificacion calificacion = calificacionService.findById(id);
        if (calificacion == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(calificacion));
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Crear una nueva calificación", description = "Registra una nueva calificación en el sistema, permitiendo incluir un comentario y una puntuación para un baño específico")

    public ResponseEntity<EntityModel<Calificacion>> createCalificacion(@RequestBody Calificacion calificacion) {
        Calificacion nuevaCalificacion = calificacionService.save(calificacion);
        return ResponseEntity
                .created(linkTo(methodOn(CalificacionControllerV2.class)
                        .getCalificacionById(Long.valueOf(nuevaCalificacion.getId()))).toUri())
                .body(assembler.toModel(nuevaCalificacion));
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Actualizar una calificación existente", description = "Permite modificar completamente una calificación ya registrada, reemplazando tanto el comentario como la puntuación asociados")

    public ResponseEntity<EntityModel<Calificacion>> updateCalificacion(@PathVariable Long id,
            @RequestBody Calificacion calificacion) {
        calificacion.setId(id.intValue());
        Calificacion updated = calificacionService.save(calificacion);
        if (updated == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(updated));
    }

    @PatchMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Modificar parcialmente una calificación", description = "Actualiza de forma parcial los atributos de una calificación específica, como el comentario o la puntuación")

    public ResponseEntity<EntityModel<Calificacion>> patchCalificacion(@PathVariable Long id,
            @RequestBody Calificacion calificacion) {
        Calificacion patched = calificacionService.patchCalificacion(id, calificacion);
        if (patched == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(patched));
    }

    @DeleteMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Eliminar una calificación", description = "Elimina una calificación específica del sistema, incluyendo su comentario y puntuación")

    public ResponseEntity<Void> deleteCalificacion(@PathVariable Long id) {
        Calificacion existing = calificacionService.findById(id);
        if (existing == null) {
            return ResponseEntity.notFound().build();
        }
        calificacionService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
