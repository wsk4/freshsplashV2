package com.freshsplash.cl.freshsplash.assemblers;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;
import org.springframework.stereotype.Component;

import com.freshsplash.cl.freshsplash.controller.CalificacionControllerV2;
import com.freshsplash.cl.freshsplash.model.Calificacion;

@Component
public class CalificacionModelAssembler implements RepresentationModelAssembler<Calificacion, EntityModel<Calificacion>> {

    @SuppressWarnings("null")
    @Override
    public EntityModel<Calificacion> toModel(Calificacion calificacion) {
        return EntityModel.of(calificacion,
                linkTo(methodOn(CalificacionControllerV2.class).getCalificacionById(Long.valueOf(calificacion.getId()))).withSelfRel(),
                linkTo(methodOn(CalificacionControllerV2.class).getAllCalificaciones()).withRel("todos"),
                linkTo(methodOn(CalificacionControllerV2.class).updateCalificacion(Long.valueOf(calificacion.getId()), calificacion)).withRel("actualizar"),
                linkTo(methodOn(CalificacionControllerV2.class).deleteCalificacion(Long.valueOf(calificacion.getId()))).withRel("eliminar"),
                linkTo(methodOn(CalificacionControllerV2.class).patchCalificacion(Long.valueOf(calificacion.getId()), calificacion)).withRel("actualizar-parcial")
        );
    }
}
