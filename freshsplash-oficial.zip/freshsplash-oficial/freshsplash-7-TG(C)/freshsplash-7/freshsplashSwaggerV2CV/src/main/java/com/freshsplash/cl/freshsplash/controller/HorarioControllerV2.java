package com.freshsplash.cl.freshsplash.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.freshsplash.cl.freshsplash.assemblers.HorarioModelAssembler;
import com.freshsplash.cl.freshsplash.model.Horario;
import com.freshsplash.cl.freshsplash.service.HorarioService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v2/horarios")
@Tag(name = "Api que administra los horarios de los baños-V2")

public class HorarioControllerV2 {

    @Autowired
    private HorarioService horarioService;

    @Autowired
    private HorarioModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar todos los horarios", description = "Devuelve una colección HATEOAS con todos los horarios registrados para los baños públicos.")

    public CollectionModel<EntityModel<Horario>> getAllHorarios() {
        List<EntityModel<Horario>> horarios = horarioService.findAll().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(horarios,
                linkTo(methodOn(HorarioControllerV2.class).getAllHorarios()).withSelfRel());
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener horario por ID", description = "Devuelve un horario específico en formato HATEOAS, según el ID proporcionado.")

    public ResponseEntity<EntityModel<Horario>> getHorarioById(@PathVariable Long id) {
        Horario horario = horarioService.findById(id);
        if (horario == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(horario));
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Registrar un nuevo horario", description = "Crea un nuevo horario de funcionamiento para un baño público, y lo devuelve con enlaces HATEOAS.")

    public ResponseEntity<EntityModel<Horario>> createHorario(@RequestBody Horario horario) {
        Horario nuevoHorario = horarioService.save(horario);
        return ResponseEntity
                .created(linkTo(methodOn(HorarioControllerV2.class).getHorarioById(Long.valueOf(nuevoHorario.getId())))
                        .toUri())
                .body(assembler.toModel(nuevoHorario));
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Actualizar un horario", description = "Reemplaza completamente un horario existente con nueva información. Devuelve el resultado con enlaces HATEOAS.")

    public ResponseEntity<EntityModel<Horario>> updateHorario(@PathVariable Long id, @RequestBody Horario horario) {
        horario.setId(id.intValue());
        Horario updated = horarioService.save(horario);
        if (updated == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(updated));
    }

    @PatchMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Modificar parcialmente un horario", description = "Actualiza campos específicos del horario indicado. Devuelve el resultado con enlaces HATEOAS.")

    public ResponseEntity<EntityModel<Horario>> patchHorario(@PathVariable Long id, @RequestBody Horario horario) {
        Horario patched = horarioService.patchHorario(id, horario);
        if (patched == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(patched));
    }

    @DeleteMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Eliminar un horario", description = "Elimina el horario asociado al ID especificado. Devuelve una respuesta sin contenido si tiene éxito.")

    public ResponseEntity<Void> deleteHorario(@PathVariable Long id) {
        Horario existing = horarioService.findById(id);
        if (existing == null) {
            return ResponseEntity.notFound().build();
        }
        horarioService.delete(id);
        return ResponseEntity.noContent().build();
    }

}
