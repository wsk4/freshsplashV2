package com.freshsplash.cl.freshsplash.assemblers;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;
import org.springframework.stereotype.Component;

import com.freshsplash.cl.freshsplash.controller.EtiquetaControllerV2;
import com.freshsplash.cl.freshsplash.model.Etiqueta;

@Component
public class EtiquetaModelAssembler implements RepresentationModelAssembler<Etiqueta, EntityModel<Etiqueta>> {

    @SuppressWarnings("null")
    @Override
    public EntityModel<Etiqueta> toModel(Etiqueta etiqueta) {
        return EntityModel.of(etiqueta,
                linkTo(methodOn(EtiquetaControllerV2.class).getEtiquetaById(Long.valueOf(etiqueta.getId()))).withSelfRel(),
                linkTo(methodOn(EtiquetaControllerV2.class).getAllEtiquetas()).withRel("todos"),
                linkTo(methodOn(EtiquetaControllerV2.class).updateEtiqueta(Long.valueOf(etiqueta.getId()), etiqueta)).withRel("actualizar"),
                linkTo(methodOn(EtiquetaControllerV2.class).deleteEtiqueta(Long.valueOf(etiqueta.getId()))).withRel("eliminar"),
                linkTo(methodOn(EtiquetaControllerV2.class).patchEtiqueta(Long.valueOf(etiqueta.getId()), etiqueta)).withRel("actualizar-parcial")
        );
    }
}
