package com.freshsplash.cl.freshsplash.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.freshsplash.cl.freshsplash.assemblers.BanoModelAssembler;
import com.freshsplash.cl.freshsplash.model.Bano;
import com.freshsplash.cl.freshsplash.service.BanoService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v2/baños")
@Tag(name = "API de gestión de baños públicos - V2")
public class BanoControllerV2 {

    @Autowired
    private BanoService banoService;

    @Autowired
    private BanoModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Listar todos los baños", description = "Retorna un listado HATEOAS de todos los baños disponibles en el sistema")
    public CollectionModel<EntityModel<Bano>> getAllBanos() {
        List<EntityModel<Bano>> banos = banoService.findAll().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(banos,
                linkTo(methodOn(BanoControllerV2.class).getAllBanos()).withSelfRel());
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener detalles de un baño por ID", description = "Devuelve la información detallada y enriquecida de un baño específico, incluyendo enlaces HATEOAS")
    public ResponseEntity<EntityModel<Bano>> getBanoById(@PathVariable Long id) {
        Bano bano = banoService.findById(id);
        if (bano == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(bano));
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Registrar un nuevo baño", description = "Crea un nuevo baño en el sistema y retorna su representación HATEOAS")
    public ResponseEntity<EntityModel<Bano>> createBano(@RequestBody Bano bano) {
        Bano nuevoBano = banoService.save(bano);
        return ResponseEntity
                .created(linkTo(methodOn(BanoControllerV2.class).getBanoById((long) nuevoBano.getId())).toUri())
                .body(assembler.toModel(nuevoBano));
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Actualiza un baño por completo", description = "Modifica campos específicos de un baño existente sin reemplazar su totalidad")
    public ResponseEntity<EntityModel<Bano>> updateBano(@PathVariable Long id, @RequestBody Bano bano) {
        bano.setId(id.intValue());
        Bano updated = banoService.save(bano);
        if (updated == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(updated));
    }

    @PatchMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Modifica parcialmente un baño", description = "Modifica campos específicos de un baño existente sin reemplazar su totalidad")
    public ResponseEntity<EntityModel<Bano>> patchBano(@PathVariable Long id, @RequestBody Bano bano) {
        Bano patched = banoService.patchBano(id, bano);
        if (patched == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(patched));
    }

    @DeleteMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Eliminar un baño", description = "Elimina de forma permanente un baño identificado por su ID")
    public ResponseEntity<Void> deleteBano(@PathVariable Long id) {
        Bano existing = banoService.findById(id);
        if (existing == null) {
            return ResponseEntity.notFound().build();
        }
        banoService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping(value = "/filtrar", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Filtrar baños por región, precio máximo y puntuación mínima", description = "Permite obtener baños ubicados en una región específica, con un precio máximo definido y una puntuación igual o superior a la indicada")
    public CollectionModel<EntityModel<Bano>> getFiltrarPorRegionPrecioYPuntuacion(
            @RequestParam String region,
            @RequestParam Integer precio,
            @RequestParam Integer puntuacion) {
        List<EntityModel<Bano>> banos = banoService.findByRegionPrecioYPuntuacion(region, precio, puntuacion).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(banos,
                linkTo(methodOn(BanoControllerV2.class).getFiltrarPorRegionPrecioYPuntuacion(region, precio, puntuacion)).withSelfRel());
    }

    @GetMapping(value = "/filtrar/comuna-acceso-puntuacion", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Filtrar baños por comuna, accesibilidad y puntuación mínima", description = "Busca baños en una comuna específica, considerando accesibilidad para personas con discapacidad y una puntuación mínima")
    public CollectionModel<EntityModel<Bano>> getFiltrarPorComunaAccesoDiscapacitadoYPuntuacion(
            @RequestParam String comuna,
            @RequestParam boolean accesoDiscapacitado,
            @RequestParam Integer puntuacion) {
        List<EntityModel<Bano>> banos = banoService.findByComunaAccesoDiscapacitadoYPuntuacion(comuna, accesoDiscapacitado, puntuacion).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(banos,
                linkTo(methodOn(BanoControllerV2.class).getFiltrarPorComunaAccesoDiscapacitadoYPuntuacion(comuna, accesoDiscapacitado, puntuacion)).withSelfRel());
    }

    @GetMapping(value = "/filtrar/ciudad-gratuito-puntuacion", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Filtrar baños por ciudad, gratuidad y puntuación mínima", description = "Devuelve baños que se encuentren en una ciudad específica, sean gratuitos y cumplan con una puntuación mínima")
    public CollectionModel<EntityModel<Bano>> getFindByCiudadEtiquetaGratuitoYPuntuacion(
            @RequestParam String ciudad,
            @RequestParam boolean gratuito,
            @RequestParam Integer puntuacion) {
        List<EntityModel<Bano>> banos = banoService.findByCiudadEtiquetaGratuitoYPuntuacion(ciudad, gratuito, puntuacion).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(banos,
                linkTo(methodOn(BanoControllerV2.class).getFindByCiudadEtiquetaGratuitoYPuntuacion(ciudad, gratuito, puntuacion)).withSelfRel());
    }

    @GetMapping(value = "/filtrar/pais-tipositio-puntuacion", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Filtrar baños por país, tipo de sitio y puntuación mínima", description = "Permite obtener baños ubicados en un país específico, filtrando por tipo de sitio y puntuación mínima")
    public CollectionModel<EntityModel<Bano>> getFiltrarPorPaisTipoSitioYPuntuacionMinima(
            @RequestParam String pais,
            @RequestParam Integer tipoSitioId,
            @RequestParam Integer minPuntuacion) {
        List<EntityModel<Bano>> banos = banoService.findByPaisTipoSitioYPuntuacionMinima(pais, tipoSitioId, minPuntuacion).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(banos,
                linkTo(methodOn(BanoControllerV2.class).getFiltrarPorPaisTipoSitioYPuntuacionMinima(pais, tipoSitioId, minPuntuacion)).withSelfRel());
    }

}
