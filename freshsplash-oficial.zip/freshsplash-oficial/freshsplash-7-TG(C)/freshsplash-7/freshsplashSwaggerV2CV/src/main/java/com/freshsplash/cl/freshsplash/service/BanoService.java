package com.freshsplash.cl.freshsplash.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.freshsplash.cl.freshsplash.model.Bano;
import com.freshsplash.cl.freshsplash.model.Etiqueta;
import com.freshsplash.cl.freshsplash.repository.BanoRepository;
import com.freshsplash.cl.freshsplash.repository.CalificacionRepository;
import com.freshsplash.cl.freshsplash.repository.DiasAbiertoRepository;
import com.freshsplash.cl.freshsplash.repository.EtiquetaRepository;
import com.freshsplash.cl.freshsplash.repository.HorarioRepository;
import com.freshsplash.cl.freshsplash.repository.ImagenRepository;
import com.freshsplash.cl.freshsplash.repository.UbicacionRepository;

import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class BanoService {

    @Autowired
    private BanoRepository banoRepository;

    @Autowired
    private CalificacionRepository calificacionRepository;

    @Autowired
    private DiasAbiertoRepository diasAbiertoRepository;

    @Autowired
    private EtiquetaRepository etiquetaRepository;

    @Autowired
    private HorarioRepository horarioRepository;

    @Autowired
    private ImagenRepository imagenRepository;

    @Autowired
    private UbicacionRepository ubicacionRepository;

    public List<Bano> findAll() {
        return banoRepository.findAll();
    }

    public Bano findById(Long id) {
        return banoRepository.findById(id.intValue()).orElse(null);
    }

    public Bano save(Bano bano) {
        return banoRepository.save(bano);
    }

    public void delete(Long id) {
        banoRepository.deleteById(id.intValue());
    }

    public void eliminarBanoConRelaciones(Integer idBano) {
        Optional<Bano> optionalBano = banoRepository.findById(idBano);

        if (optionalBano.isPresent()) {
            Bano bano = optionalBano.get();

            List<Etiqueta> etiquetas = etiquetaRepository.findByBano(bano);
            if (!etiquetas.isEmpty()) {
                etiquetaRepository.deleteAll(etiquetas);
            }

            calificacionRepository.deleteByBano(bano);
            diasAbiertoRepository.deleteByBano(bano);
            horarioRepository.deleteByBano(bano);
            imagenRepository.deleteByBano(bano);
            ubicacionRepository.deleteByBano(bano);

            banoRepository.delete(bano);
        } else {
            throw new EntityNotFoundException("Baño no encontrado con ID: " + idBano);
        }
    }

    public Bano patchBano(Long id, Bano partialBano) {
        Optional<Bano> optionalBano = banoRepository.findById(id.intValue());
        if (optionalBano.isPresent()) {
            Bano banoToUpdate = optionalBano.get();

            // Aplica solo los campos no nulos del objeto parcial
            if (partialBano.getCapacidad() != null) {
                banoToUpdate.setCapacidad(partialBano.getCapacidad());
            }
            if (partialBano.getImagen() != null) {
                banoToUpdate.setImagen(partialBano.getImagen());
            }
            if (partialBano.getUbicacion() != null) {
                banoToUpdate.setUbicacion(partialBano.getUbicacion());
            }
            if (partialBano.getHorario() != null) {
                banoToUpdate.setHorario(partialBano.getHorario());
            }
            if (partialBano.getEtiqueta() != null) {
                banoToUpdate.setEtiqueta(partialBano.getEtiqueta());
            }
            if (partialBano.getCalificacion() != null) {
                banoToUpdate.setCalificacion(partialBano.getCalificacion());
            }

            return banoRepository.save(banoToUpdate);
        } else {
            return null;
        }
    }

    public List<Bano> findByRegionPrecioYPuntuacion(String region, Integer precio, Integer puntuacion) {
        return banoRepository.findByRegionPrecioYPuntuacion(region, precio, puntuacion);
    }

    public List<Bano> findByComunaAccesoDiscapacitadoYPuntuacion(String comuna, boolean accesoDiscapacitado,
            Integer puntuacion) {
        return banoRepository.findByComunaAccesoDiscapacitadoYPuntuacion(comuna, accesoDiscapacitado, puntuacion);
    }

    public List<Bano> findByCiudadEtiquetaGratuitoYPuntuacion(String ciudad, boolean gratuito, Integer puntuacion) {
        return banoRepository.findByCiudadEtiquetaGratuitoYPuntuacion(ciudad, gratuito, puntuacion);
    }

    public List<Bano> findByPaisTipoSitioYPuntuacionMinima(String pais, Integer tipoSitioId, Integer minPuntuacion) {
        return banoRepository.findByPaisTipoSitioYPuntuacionMinima(pais, tipoSitioId, minPuntuacion);
    }

}
