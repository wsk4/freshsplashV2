package com.freshsplash.cl.freshsplash.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.freshsplash.cl.freshsplash.model.Bano;
import com.freshsplash.cl.freshsplash.model.TipoSitio;

public interface TipoSitioRepository extends JpaRepository<TipoSitio, Integer> {

    void deleteByBano(Bano bano);

}
