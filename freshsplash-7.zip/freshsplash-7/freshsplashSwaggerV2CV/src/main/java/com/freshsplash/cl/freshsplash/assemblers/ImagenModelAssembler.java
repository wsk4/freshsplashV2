package com.freshsplash.cl.freshsplash.assemblers;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;
import org.springframework.stereotype.Component;

import com.freshsplash.cl.freshsplash.controller.ImagenControllerV2;
import com.freshsplash.cl.freshsplash.model.Imagen;

@Component
public class ImagenModelAssembler implements RepresentationModelAssembler<Imagen, EntityModel<Imagen>> {

    @SuppressWarnings("null")
    @Override
    public EntityModel<Imagen> toModel(Imagen imagen) {
        return EntityModel.of(imagen,
                linkTo(methodOn(ImagenControllerV2.class).getImagenById(Long.valueOf(imagen.getId()))).withSelfRel(),
                linkTo(methodOn(ImagenControllerV2.class).getAllImagenes()).withRel("todos"),
                linkTo(methodOn(ImagenControllerV2.class).updateImagen(Long.valueOf(imagen.getId()), imagen)).withRel("actualizar"),
                linkTo(methodOn(ImagenControllerV2.class).deleteImagen(Long.valueOf(imagen.getId()))).withRel("eliminar"),
                linkTo(methodOn(ImagenControllerV2.class).patchImagen(Long.valueOf(imagen.getId()), imagen)).withRel("actualizar-parcial")
        );
    }
}
