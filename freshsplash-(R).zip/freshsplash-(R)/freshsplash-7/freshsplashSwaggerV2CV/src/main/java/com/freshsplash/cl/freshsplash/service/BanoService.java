package com.freshsplash.cl.freshsplash.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.freshsplash.cl.freshsplash.model.Bano;
import com.freshsplash.cl.freshsplash.repository.BanoRepository;


@Service
public class BanoService {

    @Autowired
    private BanoRepository banoRepository;

   

   

    public List<Bano> findAll() {
        return banoRepository.findAll();
    }

    public Bano findById(Long id) {
        return banoRepository.findById(id.intValue()).orElse(null);
    }

    public Bano save(Bano bano) {
        return banoRepository.save(bano);
    }

    public void delete(Long id) {
        banoRepository.deleteById(id.intValue());
    }

    public Bano patchBano(Long id, Bano partialBano) {
        Optional<Bano> optionalBano = banoRepository.findById(id.intValue());
        if (optionalBano.isPresent()) {
            Bano banoToUpdate = optionalBano.get();

            if (partialBano.getCapacidad() != null) {
                banoToUpdate.setCapacidad(partialBano.getCapacidad());
            }
            if (partialBano.getImagen() != null) {
                banoToUpdate.setImagen(partialBano.getImagen());
            }
            if (partialBano.getUbicacion() != null) {
                banoToUpdate.setUbicacion(partialBano.getUbicacion());
            }
            if (partialBano.getHorario() != null) {
                banoToUpdate.setHorario(partialBano.getHorario());
            }
            if (partialBano.getEtiqueta() != null) {
                banoToUpdate.setEtiqueta(partialBano.getEtiqueta());
            }
            if (partialBano.getCalificacion() != null) {
                banoToUpdate.setCalificacion(partialBano.getCalificacion());
            }

            return banoRepository.save(banoToUpdate);
        } else {
            return null;
        }
    }


  
}
