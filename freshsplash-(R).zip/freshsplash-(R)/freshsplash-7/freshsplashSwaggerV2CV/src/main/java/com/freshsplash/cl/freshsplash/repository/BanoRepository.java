package com.freshsplash.cl.freshsplash.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.freshsplash.cl.freshsplash.model.Bano;
import com.freshsplash.cl.freshsplash.model.Calificacion;
import com.freshsplash.cl.freshsplash.model.Etiqueta;
import com.freshsplash.cl.freshsplash.model.Horario;
import com.freshsplash.cl.freshsplash.model.Imagen;
import com.freshsplash.cl.freshsplash.model.Ubicacion;


@Repository
public interface BanoRepository extends JpaRepository<Bano, Integer> {

    void deleteByEtiqueta(Etiqueta etiqueta);


    void deletedeleteByHorario(Horario horario);

    void deleteByUbicacion(Ubicacion ubicacion);


    void deletedeleteByCalificacion(Calificacion calificacion);

    void deletedeleteByImagen(Imagen imagen);


}
