package com.freshsplash.cl.freshsplash.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.freshsplash.cl.freshsplash.assemblers.HorarioModelAssembler;
import com.freshsplash.cl.freshsplash.model.Horario;
import com.freshsplash.cl.freshsplash.service.HorarioService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v2/horarios")
@Tag(name = "Api que administra los horarios de los bañosV2")

public class HorarioControllerV2 {

    @Autowired
    private HorarioService horarioService;

    @Autowired
    private HorarioModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Esta api llamara a todos los horarios de los baños", description = "Esta api permitira llamara a todos los horarios de los baños")

    public CollectionModel<EntityModel<Horario>> getAllHorarios() {
        List<EntityModel<Horario>> horarios = horarioService.findAll().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(horarios,
                linkTo(methodOn(HorarioControllerV2.class).getAllHorarios()).withSelfRel());
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Esta api llamara el horario", description = "Esta api permitira llamar a un baño segun su horario")

    public ResponseEntity<EntityModel<Horario>> getHorarioById(@PathVariable Long id) {
        Horario horario = horarioService.findById(id);
        if (horario == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(horario));
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Esta api creara el horario de un baño", description = "Esta api permitira crear el horario de un baño")

    public ResponseEntity<EntityModel<Horario>> createHorario(@RequestBody Horario horario) {
        Horario nuevoHorario = horarioService.save(horario);
        return ResponseEntity
                .created(linkTo(methodOn(HorarioControllerV2.class).getHorarioById(Long.valueOf(nuevoHorario.getId()))).toUri())
                .body(assembler.toModel(nuevoHorario));
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Esta api actualizara el horario de un baño", description = "Esta api permitira actualizar el horario de un baño")

    public ResponseEntity<EntityModel<Horario>> updateHorario(@PathVariable Long id, @RequestBody Horario horario) {
        horario.setId(id.intValue());
        Horario updated = horarioService.save(horario);
        if (updated == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(updated));
    }

    @PatchMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Esta api modificara el horario de un baño", description = "Esta api permitira modificar el horario de un baño")

    public ResponseEntity<EntityModel<Horario>> patchHorario(@PathVariable Long id, @RequestBody Horario horario) {
        Horario patched = horarioService.patchHorario(id, horario);
        if (patched == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(patched));
    }

    @DeleteMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Esta api eliminara el horario de un baño", description = "Esta api permitira eliminar el horario de un baño")

    public ResponseEntity<Void> deleteHorario(@PathVariable Long id) {
        Horario existing = horarioService.findById(id);
        if (existing == null) {
            return ResponseEntity.notFound().build();
        }
        horarioService.delete(id);
        return ResponseEntity.noContent().build();
    }

}
