package com.freshsplash.cl.freshsplash.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.freshsplash.cl.freshsplash.model.Etiqueta;
import com.freshsplash.cl.freshsplash.model.TipoSitio;


@Repository
public interface EtiquetaRepository extends JpaRepository<Etiqueta, Long> {

    
    void deletedeleteByTipoSitio(TipoSitio tipoSitio);

}
