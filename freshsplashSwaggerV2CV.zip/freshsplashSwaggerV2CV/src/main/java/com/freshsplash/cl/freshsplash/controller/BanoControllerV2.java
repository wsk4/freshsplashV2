package com.freshsplash.cl.freshsplash.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.freshsplash.cl.freshsplash.assemblers.BanoModelAssembler;
import com.freshsplash.cl.freshsplash.model.Bano;
import com.freshsplash.cl.freshsplash.service.BanoService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v2/baños")
@Tag(name = "Api que administra la informacion de los bañosV2")

public class BanoControllerV2 {

    @Autowired
    private BanoService banoService;

    @Autowired
    private BanoModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary="Esta api obtendra todoslos baños",description="Esta api permitira obtener todos los baños")
    public CollectionModel<EntityModel<Bano>> getAllBanos() {
        List<EntityModel<Bano>> banos = banoService.findAll().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(banos,
                linkTo(methodOn(BanoControllerV2.class).getAllBanos()).withSelfRel());
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary="Esta api obtendra un baño especifico",description="Esta api permitira obtener un baño especifico")

    public ResponseEntity<EntityModel<Bano>> getBanoById(@PathVariable Long id) {
        Bano bano = banoService.findById(id);
        if (bano == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(bano));
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary="Esta api obtendra un baño por su id",description="Esta api permitira retornar los detalles de un baño especifico")

    public ResponseEntity<EntityModel<Bano>> getBanoByIdWithSala(@PathVariable Long id) {
        Bano bano = banoService.findById(id);
        if (bano == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(bano));
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary="Esta api creara un nuevo baño",description="Esta api permitira crear un nuevo baño")

    public ResponseEntity<EntityModel<Bano>> createBano(@RequestBody Bano bano) {
        Bano nuevoBano = banoService.save(bano);
        return ResponseEntity
                .created(linkTo(methodOn(BanoControllerV2.class).getBanoById(Long.valueOf(nuevoBano.getId()))).toUri())
                .body(assembler.toModel(nuevoBano));
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary="Esta api actualizara un baño",description="Esta api permitira actualizar un baño")

    public ResponseEntity<EntityModel<Bano>> updateBano(@PathVariable Long id, @RequestBody Bano bano) {
        bano.setId(id.intValue());
        Bano updated = banoService.save(bano);
        if (updated == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(updated));
    }

    @PatchMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary="Esta api modificara un baño",description="Esta api permitira modificar un baño")

    public ResponseEntity<EntityModel<Bano>> patchBano(@PathVariable Long id, @RequestBody Bano bano) {
        Bano patched = banoService.patchBano(id, bano);
        if (patched == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(patched));
    }

    @DeleteMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary="Esta api eliminara un baño",description="Esta api permitira eliminar un baño")

    public ResponseEntity<Void> deleteBano(@PathVariable Long id) {
        Bano existing = banoService.findById(id);
        if (existing == null) {
            return ResponseEntity.notFound().build();
        }
        banoService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
