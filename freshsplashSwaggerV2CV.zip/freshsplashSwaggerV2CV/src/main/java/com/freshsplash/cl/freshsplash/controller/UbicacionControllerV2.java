package com.freshsplash.cl.freshsplash.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.freshsplash.cl.freshsplash.assemblers.UbicacionModelAssembler;
import com.freshsplash.cl.freshsplash.model.Ubicacion;
import com.freshsplash.cl.freshsplash.service.UbicacionService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v2/ubicaciones")
@Tag(name = "Api que administra las ubicaciones de los bañosV2")

public class UbicacionControllerV2 {

    @Autowired
    private UbicacionService ubicacionService;

    @Autowired
    private UbicacionModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary="Esta api obtendra todas las ubicaciones de los baños", description="Esta api permitira mostrar todos los horarios de los baños")
    public CollectionModel<EntityModel<Ubicacion>> getAllUbicaciones() {
        List<EntityModel<Ubicacion>> ubicaciones = ubicacionService.findAll().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(ubicaciones,
                linkTo(methodOn(UbicacionControllerV2.class).getAllUbicaciones()).withSelfRel());
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary="Esta api obtendra la ubicacionde un baño", description="Esta api permitira obtener la ubicacion de un baño")

    public ResponseEntity<EntityModel<Ubicacion>> getUbicacionById(@PathVariable Long id) {
        Ubicacion ubicacion = ubicacionService.findById(id);
        if (ubicacion == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(ubicacion));
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary="Esta api creara la ubicacion de un baño", description="Esta api permitira crear la ubicacion de un baño")

    public ResponseEntity<EntityModel<Ubicacion>> createUbicacion(@RequestBody Ubicacion ubicacion) {
        Ubicacion nuevaUbicacion = ubicacionService.save(ubicacion);
        return ResponseEntity
                .created(linkTo(methodOn(UbicacionControllerV2.class).getUbicacionById(Long.valueOf(nuevaUbicacion.getId()))).toUri())
                .body(assembler.toModel(nuevaUbicacion));
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary="Esta api actualizara la ubicacion de un baño", description="Esta api permitira actualizar la ubicacion de un baño")

    public ResponseEntity<EntityModel<Ubicacion>> updateUbicacion(@PathVariable Long id, @RequestBody Ubicacion ubicacion) {
        ubicacion.setId(id.intValue());
        Ubicacion updated = ubicacionService.save(ubicacion);
        if (updated == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(updated));
    }

    @PatchMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary="Esta api modificara la ubicacion de un baño", description="Esta api permitira modificar la ubicacion de un baño")

    public ResponseEntity<EntityModel<Ubicacion>> patchUbicacion(@PathVariable Long id, @RequestBody Ubicacion ubicacion) {
        Ubicacion patched = ubicacionService.patchUbicacion(id, ubicacion);
        if (patched == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(patched));
    }

    @DeleteMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary="Esta api eliminara la ubicacion de un baño", description="Esta api permitira eliminar la ubicacion de un baño")

    public ResponseEntity<Void> deleteUbicacion(@PathVariable Long id) {
        Ubicacion existing = ubicacionService.findById(id);
        if (existing == null) {
            return ResponseEntity.notFound().build();
        }
        ubicacionService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping(value = "/pais/{pais}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Esta API obtiene ubicaciones según el país", description = "Permite obtener la ubicación de un baño según el país solicitado")
    public ResponseEntity<CollectionModel<EntityModel<Ubicacion>>> buscarPorPais(@PathVariable String pais) {
        List<Ubicacion> ubicaciones = ubicacionService.findByPais(pais);
        if (ubicaciones.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        List<EntityModel<Ubicacion>> ubicacionesModel = ubicaciones.stream()
                .map(assembler::toModel)
                .toList();
        return ResponseEntity.ok(CollectionModel.of(ubicacionesModel));
    }

    @GetMapping(value = "/region/{region}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Esta API obtiene ubicaciones según la región", description = "Permite obtener la ubicación de un baño según la región solicitada")
    public ResponseEntity<CollectionModel<EntityModel<Ubicacion>>> buscarPorRegion(@PathVariable String region) {
        List<Ubicacion> ubicaciones = ubicacionService.findByRegion(region);
        if (ubicaciones.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        List<EntityModel<Ubicacion>> ubicacionesModel = ubicaciones.stream()
                .map(assembler::toModel)
                .toList();
        return ResponseEntity.ok(CollectionModel.of(ubicacionesModel));
    }

    @GetMapping(value = "/ciudad/{ciudad}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Esta API obtiene ubicaciones según la ciudad", description = "Permite obtener la ubicación de un baño según la ciudad solicitada")
    public ResponseEntity<CollectionModel<EntityModel<Ubicacion>>> buscarPorCiudad(@PathVariable String ciudad) {
        List<Ubicacion> ubicaciones = ubicacionService.findByCiudad(ciudad);
        if (ubicaciones.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        List<EntityModel<Ubicacion>> ubicacionesModel = ubicaciones.stream()
                .map(assembler::toModel)
                .toList();
        return ResponseEntity.ok(CollectionModel.of(ubicacionesModel));
    }

    @GetMapping(value = "/comuna/{comuna}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Esta API obtiene ubicaciones según la comuna", description = "Permite obtener la ubicación de un baño según la comuna solicitada")
    public ResponseEntity<CollectionModel<EntityModel<Ubicacion>>> buscarPorComuna(@PathVariable String comuna) {
        List<Ubicacion> ubicaciones = ubicacionService.findByComuna(comuna);
        if (ubicaciones.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        List<EntityModel<Ubicacion>> ubicacionesModel = ubicaciones.stream()
                .map(assembler::toModel)
                .toList();
        return ResponseEntity.ok(CollectionModel.of(ubicacionesModel));
    }

    @GetMapping(value = "/direccion/{direccion}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Esta API obtiene ubicaciones según la dirección", description = "Permite obtener la ubicación de un baño según la dirección solicitada")
    public ResponseEntity<CollectionModel<EntityModel<Ubicacion>>> buscarPorDireccion(@PathVariable String direccion) {
        List<Ubicacion> ubicaciones = ubicacionService.findByDireccion(direccion);
        if (ubicaciones.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        List<EntityModel<Ubicacion>> ubicacionesModel = ubicaciones.stream()
                .map(assembler::toModel)
                .toList();
        return ResponseEntity.ok(CollectionModel.of(ubicacionesModel));
    }

}
