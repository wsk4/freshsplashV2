package com.freshsplash.cl.freshsplash.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.freshsplash.cl.freshsplash.assemblers.CalificacionModelAssembler;
import com.freshsplash.cl.freshsplash.model.Calificacion;
import com.freshsplash.cl.freshsplash.service.CalificacionService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v2/calificaciones")
@Tag(name = "Api que controla las comentarios y puntuaciones de los bañosV2")

public class CalificacionControllerV2 {

    @Autowired
    private CalificacionService calificacionService;

    @Autowired
    private CalificacionModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Esta api llama a todas las calificaciones de los baños", description = "Esta api llama a todos los comentarios y las puntuaciones que coloca la gente de los baños")

    public CollectionModel<EntityModel<Calificacion>> getAllCalificaciones() {
        List<EntityModel<Calificacion>> calificaciones = calificacionService.findAll().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(calificaciones,
                linkTo(methodOn(CalificacionControllerV2.class).getAllCalificaciones()).withSelfRel());
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Esta api llama a una calificacion especifica de un baño", description = "Esta api llama al comentario y calificacion especifica que se le ha colocado a un baño")

    public ResponseEntity<EntityModel<Calificacion>> getCalificacionById(@PathVariable Long id) {
        Calificacion calificacion = calificacionService.findById(id);
        if (calificacion == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(calificacion));
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary="Esta api crea una calificacion de un baño",description="Esta api permitira crear una calificacion a los baños")

    public ResponseEntity<EntityModel<Calificacion>> createCalificacion(@RequestBody Calificacion calificacion) {
        Calificacion nuevaCalificacion = calificacionService.save(calificacion);
        return ResponseEntity
                .created(linkTo(methodOn(CalificacionControllerV2.class).getCalificacionById(Long.valueOf(nuevaCalificacion.getId()))).toUri())
                .body(assembler.toModel(nuevaCalificacion));
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary="Esta api actualizara una calificacion a un baño",description="Esta api permitira actualizar la calificacion de un baño")

    public ResponseEntity<EntityModel<Calificacion>> updateCalificacion(@PathVariable Long id, @RequestBody Calificacion calificacion) {
        calificacion.setId(id.intValue());
        Calificacion updated = calificacionService.save(calificacion);
        if (updated == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(updated));
    }

    @PatchMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary="Esta api modificara la calificacion de un baño ",description="Esta api permitira modificar la calificacion de un baño")

    public ResponseEntity<EntityModel<Calificacion>> patchCalificacion(@PathVariable Long id, @RequestBody Calificacion calificacion) {
        Calificacion patched = calificacionService.patchCalificacion(id, calificacion);
        if (patched == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(patched));
    }

    @DeleteMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary="Esta api eliminara la calificacion de un baño",description="Esta api permitira eliminar la calificacion de un baño")

    public ResponseEntity<Void> deleteCalificacion(@PathVariable Long id) {
        Calificacion existing = calificacionService.findById(id);
        if (existing == null) {
            return ResponseEntity.notFound().build();
        }
        calificacionService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
