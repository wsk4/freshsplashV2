package com.freshsplash.cl.freshsplash.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.freshsplash.cl.freshsplash.model.Bano;
import com.freshsplash.cl.freshsplash.model.Etiqueta;
import com.freshsplash.cl.freshsplash.repository.BanoRepository;
import com.freshsplash.cl.freshsplash.repository.CalificacionRepository;
import com.freshsplash.cl.freshsplash.repository.DiasAbiertoRepository;
import com.freshsplash.cl.freshsplash.repository.EtiquetaRepository;
import com.freshsplash.cl.freshsplash.repository.HorarioRepository;
import com.freshsplash.cl.freshsplash.repository.ImagenRepository;
import com.freshsplash.cl.freshsplash.repository.TipoSitioRepository;
import com.freshsplash.cl.freshsplash.repository.UbicacionRepository;

import jakarta.persistence.EntityNotFoundException;
import lombok.Data;

@Data
@Service
public class BanoService {

    @Autowired
    private BanoRepository banoRepository;

    @Autowired
    private CalificacionRepository calificacionRepository;

    @Autowired
    private DiasAbiertoRepository diasAbiertoRepository;

    @Autowired
    private EtiquetaRepository etiquetaRepository;

    @Autowired
    private HorarioRepository horarioRepository;

    @Autowired
    private ImagenRepository imagenRepository;

    @Autowired
    private TipoSitioRepository tipoSitioRepository;

    @Autowired
    private UbicacionRepository ubicacionRepository;

   
    @Transactional
public void eliminarBanoConRelaciones(Integer idBano) {
    Optional<Bano> optionalBano = banoRepository.findById(idBano);

    if (optionalBano.isPresent()) {
        Bano bano = optionalBano.get();

        
        List<Etiqueta> etiquetas = etiquetaRepository.findByBano(bano);
        if (!etiquetas.isEmpty()) {
            etiquetaRepository.deleteAll(etiquetas);
        }

        
        calificacionRepository.deleteByBano(bano);
        diasAbiertoRepository.deleteByBano(bano);
        horarioRepository.deleteByBano(bano);
        imagenRepository.deleteByBano(bano);
        ubicacionRepository.deleteByBano(bano);

        
        banoRepository.delete(bano);
    } else {
        throw new EntityNotFoundException("Baño no encontrado con ID: " + idBano);
    }
}

}
