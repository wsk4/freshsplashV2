package com.freshsplash.cl.freshsplash.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.freshsplash.cl.freshsplash.model.Bano;



@Repository
public interface BanoRepository extends JpaRepository<Bano, Integer> {

    // Buscar baños por ciudad, día y etiqueta
    @Query("SELECT b FROM Bano b " +
           "JOIN b.ubicacion u " +
           "JOIN b.horario h " +
           "JOIN b.etiqueta e " +
           "WHERE u.ciudad = :ciudad " +
           "AND h.dia = :dia " +
           "AND e.nombre = :etiqueta")
    List<Bano> findByCiudadDiaYEtiqueta(@Param("ciudad") String ciudad,
                                        @Param("dia") String dia,
                                        @Param("etiqueta") String etiqueta);

    // Buscar baños por comuna y rango horario (hora actual dentro de apertura/cierre)
    @Query("SELECT b FROM Bano b " +
           "JOIN b.ubicacion u " +
           "JOIN b.horario h " +
           "WHERE u.comuna = :comuna " +
           "AND h.dia = :dia " +
           "AND :hora BETWEEN h.horaApertura AND h.horaCierre")
    List<Bano> findAbiertosEnComuna(@Param("comuna") String comuna,
                                    @Param("dia") String dia,
                                    @Param("hora") String hora);

    // un filtro por puntaje mínimo
   @Query("SELECT b FROM Bano b " +
       "JOIN b.ubicacion u " +
       "JOIN b.etiqueta e " +
       "JOIN b.calificacion c " +
       "WHERE u.region = :region " +
       "AND e.nombre = :etiqueta " +
       "AND c.puntuacion >= :puntuacionMinima")
List<Bano> findByRegionEtiquetaYPuntuacion(@Param("region") String region,
                                           @Param("etiqueta") String etiqueta,
                                           @Param("puntuacionMinima") Integer puntuacionMinima);

    // Buscar baños por país, ciudad, comuna y día
    @Query("SELECT b FROM Bano b " +
           "JOIN b.ubicacion u " +
           "JOIN b.horario h " +
           "WHERE u.pais = :pais " +
           "AND u.ciudad = :ciudad " +
           "AND u.comuna = :comuna " +
           "AND h.dia = :dia")
    List<Bano> findByPaisCiudadComunaYDia(@Param("pais") String pais,
                                          @Param("ciudad") String ciudad,
                                          @Param("comuna") String comuna,
                                          @Param("dia") String dia);




                                   }

