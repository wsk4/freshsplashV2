package com.freshsplash.cl.freshsplash.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.freshsplash.cl.freshsplash.model.Bano;
import com.freshsplash.cl.freshsplash.model.DiasAbierto;

public interface DiasAbiertoRepository extends JpaRepository<DiasAbierto, Integer> {

    void deleteByBano(Bano bano);
}
