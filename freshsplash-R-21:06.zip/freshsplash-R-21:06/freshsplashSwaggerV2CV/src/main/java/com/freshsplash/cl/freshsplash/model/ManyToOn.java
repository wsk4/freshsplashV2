package com.freshsplash.cl.freshsplash.model;

public @interface ManyToOn {

}
