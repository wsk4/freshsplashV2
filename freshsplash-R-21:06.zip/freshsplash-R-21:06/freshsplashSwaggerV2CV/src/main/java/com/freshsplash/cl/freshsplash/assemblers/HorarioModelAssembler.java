package com.freshsplash.cl.freshsplash.assemblers;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;
import org.springframework.stereotype.Component;

import com.freshsplash.cl.freshsplash.controller.HorarioControllerV2;
import com.freshsplash.cl.freshsplash.model.Horario;

@Component
public class HorarioModelAssembler implements RepresentationModelAssembler<Horario, EntityModel<Horario>> {

    @SuppressWarnings("null")
    @Override
    public EntityModel<Horario> toModel(Horario horario) {
        return EntityModel.of(horario,
                linkTo(methodOn(HorarioControllerV2.class).getHorarioById(Long.valueOf(horario.getId()))).withSelfRel(),
                linkTo(methodOn(HorarioControllerV2.class).getAllHorarios()).withRel("todos"),
                linkTo(methodOn(HorarioControllerV2.class).updateHorario(Long.valueOf(horario.getId()), horario)).withRel("actualizar"),
                linkTo(methodOn(HorarioControllerV2.class).deleteHorario(Long.valueOf(horario.getId()))).withRel("eliminar"),
                linkTo(methodOn(HorarioControllerV2.class).patchHorario(Long.valueOf(horario.getId()), horario)).withRel("actualizar-parcial")
        );
    }
}
