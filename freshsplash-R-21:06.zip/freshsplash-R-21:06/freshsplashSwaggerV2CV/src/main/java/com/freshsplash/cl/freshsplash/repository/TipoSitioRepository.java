package com.freshsplash.cl.freshsplash.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.freshsplash.cl.freshsplash.model.Bano;
import com.freshsplash.cl.freshsplash.model.DiasAbierto;
import com.freshsplash.cl.freshsplash.model.TipoSitio;

public interface TipoSitioRepository extends JpaRepository<TipoSitio, Integer> {


@Repository
public interface DiasAbiertoRepository extends JpaRepository<DiasAbierto, Long> {
    void deleteByBano(Bano bano);
}


}
