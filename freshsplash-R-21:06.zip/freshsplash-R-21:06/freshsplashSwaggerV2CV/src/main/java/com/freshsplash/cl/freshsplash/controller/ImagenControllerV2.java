package com.freshsplash.cl.freshsplash.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.freshsplash.cl.freshsplash.assemblers.ImagenModelAssembler;
import com.freshsplash.cl.freshsplash.model.Imagen;
import com.freshsplash.cl.freshsplash.service.ImagenService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v2/imagenes")
@Tag(name = "Api que administra los horarios de los bañosV2")

public class ImagenControllerV2 {

    @Autowired
    private ImagenService imagenService;

    @Autowired
    private ImagenModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary="Esta api obtendra todas las imagenes de los baños",description="Esta api permitira obtener todas las imagenes de un baño")

    public CollectionModel<EntityModel<Imagen>> getAllImagenes() {
        List<EntityModel<Imagen>> imagenes = imagenService.findAll().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(imagenes,
                linkTo(methodOn(ImagenControllerV2.class).getAllImagenes()).withSelfRel());
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary="Esta api obtendra la imagen de un baño",description="Esta api permitira obtener la imagen de un baño")

    public ResponseEntity<EntityModel<Imagen>> getImagenById(@PathVariable Long id) {
        Imagen imagen = imagenService.findById(id);
        if (imagen == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(imagen));
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary="Esta api creara la imagen de un baño",description="Esta api permitira crear la imagen de un baño")

    public ResponseEntity<EntityModel<Imagen>> createImagen(@RequestBody Imagen imagen) {
        Imagen nuevaImagen = imagenService.save(imagen);
        return ResponseEntity
                .created(linkTo(methodOn(ImagenControllerV2.class).getImagenById(Long.valueOf(nuevaImagen.getId()))).toUri())
                .body(assembler.toModel(nuevaImagen));
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary="Esta api actualizara la imagen de un baño",description="Esta api permitira actualizar la imagen de un baño")

    public ResponseEntity<EntityModel<Imagen>> updateImagen(@PathVariable Long id, @RequestBody Imagen imagen) {
        imagen.setId(id.intValue());
        Imagen updated = imagenService.save(imagen);
        if (updated == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(updated));
    }

    @PatchMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary="Esta api modificara la imagen de un baño",description="Esta api permitira modificar la imagen de un baño")

    public ResponseEntity<EntityModel<Imagen>> patchImagen(@PathVariable Long id, @RequestBody Imagen imagen) {
        Imagen patched = imagenService.patchImagen(id, imagen);
        if (patched == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(patched));
    }

    @DeleteMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary="Esta api eliminara la imagen de un baño",description="Esta api permitira eliminar la imagen de un baño")

    public ResponseEntity<Void> deleteImagen(@PathVariable Long id) {
        Imagen existing = imagenService.findById(id);
        if (existing == null) {
            return ResponseEntity.notFound().build();
        }
        imagenService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
