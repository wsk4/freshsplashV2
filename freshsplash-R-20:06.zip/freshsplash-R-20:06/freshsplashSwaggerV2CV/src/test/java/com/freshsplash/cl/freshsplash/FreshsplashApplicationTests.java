package com.freshsplash.cl.freshsplash;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FreshsplashApplicationTests {

	@Test
	void contextLoads() {
	}

}
